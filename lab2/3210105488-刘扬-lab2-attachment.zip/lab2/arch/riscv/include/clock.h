#ifndef _CLOCK_H
#define _CLOCK_H
void clock_set_next_event(); 
#endif